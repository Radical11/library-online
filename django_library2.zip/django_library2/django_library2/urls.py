from django.contrib import admin
from django.urls import path, include
from library import views as library_views
from library.views import RoleBasedLoginView as CustomLoginView, teacher_dashboard
from django.contrib.auth.views import LogoutView
from library.views import cancel_request_view
from library.views import unapprove_issue_view



urlpatterns = [
    path('admin/', admin.site.urls),
    path('students/', include('students.urls')),
    path('teachers/', include('teachers.urls')),

    # Auth
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),

    # Student
    path('', library_views.view_books, name='view_books'),
    path('books/', library_views.view_books, name='view-books'),
    path('books/request/<int:book_id>/', library_views.request_issue_view, name='request-issue'),

    # Teacher
    path('books/add/', library_views.add_book, name='add-book'),
    path('requests/', library_views.pending_requests_view, name='pending-requests'),
    path('requests/approve/<int:request_id>/', library_views.approve_issue_view, name='approve-issue'),
    path('requests/return/<int:request_id>/', library_views.return_book_view, name='return-book'),
    path('teachers/dashboard/', teacher_dashboard, name='teacher-dashboard'),
    path('students/dashboard/', library_views.student_dashboard, name='student-dashboard'),
    path('students/cancel-request/<int:request_id>/', cancel_request_view, name='cancel-request'),
    path('requests/unapprove/<int:request_id>/', library_views.unapprove_issue_view, name='unapprove-issue'),

]
