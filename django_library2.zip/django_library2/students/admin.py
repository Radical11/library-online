from django.contrib import admin
from .models import StudentProfile
from library.models import BookIssueRequest


@admin.register(StudentProfile)  # ✅ This handles registration
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('user',)
