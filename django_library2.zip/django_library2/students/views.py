from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login
from .forms import StudentRegisterForm
from .models import StudentProfile
from django.contrib.auth.decorators import login_required

def student_register(request):
    if request.method == 'POST':
        form = StudentRegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])  # hash password
            user.save()
            StudentProfile.objects.create(user=user)  # link profile
            return redirect('login')  # redirect to login
    else:
        form = StudentRegisterForm()
    return render(request, 'students/register.html', {'form': form})

@login_required
def view_books(request):
    if not hasattr(request.user, 'studentprofile'):
        return HttpResponseForbidden("Only students can view books.")

    books = Book.objects.all()
    return render(request, 'library/view_books.html', {'books': books})
