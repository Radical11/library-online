from django.db import models
from django.contrib.auth.models import User
from datetime import timedelta, date
from django.utils import timezone


class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    category = models.CharField(max_length=100)
    description = models.TextField()
    serial_number = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return f"{self.serial_number} - {self.title}"

class BookIssueRequest(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=[('Pending', 'Pending'), ('Approved', 'Approved'), ('Returned', 'Returned')], default='Pending')
    issued_date = models.DateField(null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    requested_date = models.DateTimeField(default=timezone.now)

    def fine_amount(self):
        if self.status != 'Returned' and self.due_date:
            today = date.today()
            weeks_late = (today - self.due_date).days // 7
            return max(0, weeks_late * 500)
        return 0