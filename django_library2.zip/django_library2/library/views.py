from django.shortcuts import render, redirect
from django.contrib.auth.views import LoginView
from django.db.models import Q
from .models import Book, BookIssueRequest
from django.contrib import messages
from django.utils import timezone
from datetime import date
from datetime import timedelta
from django.views.decorators.http import require_POST
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
import math


@login_required
def unapprove_issue_view(request, request_id):
    if not hasattr(request.user, 'teacherprofile'):
        return HttpResponseForbidden("Only teachers can unapprove requests.")

    issue_request = get_object_or_404(BookIssueRequest, id=request_id)

    # Delete the request entirely
    issue_request.delete()

    return redirect('pending-requests')


@login_required
def student_dashboard(request):
    if not hasattr(request.user, 'studentprofile'):
        return HttpResponseForbidden("Only students can view this page.")

    issued_books = BookIssueRequest.objects.filter(
        student=request.user,
        status='Approved'
    )

    for req in issued_books:
        if req.due_date and req.due_date < date.today():
            days_late = (date.today() - req.due_date).days
            if days_late > 7:
                weeks_late = math.ceil((days_late - 7) / 7)
                req.fine = (int(weeks_late) + 1) * 500
            else:
                req.fine = 0
            req.is_overdue = True
        else:
            req.fine = 0
            req.is_overdue = False

    pending_requests = BookIssueRequest.objects.filter(
        student=request.user,
        status='Pending'
    )

    return render(request, 'library/student_dashboard.html', {
        'issued_books': issued_books,
        'pending_requests': pending_requests
    })



@login_required
def teacher_dashboard(request):
    if not hasattr(request.user, 'teacherprofile'):
        return HttpResponseForbidden("Only teachers can access this page.")
    return render(request, 'library/teacher_dashboard.html')



@login_required
def pending_requests_view(request):
    if not hasattr(request.user, 'teacherprofile'):
        return HttpResponseForbidden("Only teachers can access this page.")

    # All requests with status 'Pending'
    pending = BookIssueRequest.objects.filter(status='Pending')

    # All approved but not yet returned
    approved = BookIssueRequest.objects.filter(status='Approved')

    # Optionally calculate fine (if due_date < today)

    for req in approved:
        if req.due_date and req.due_date < date.today():
            days_late = (date.today() - req.due_date).days
            if days_late > 7:
                weeks_late = math.ceil((days_late - 7) / 7)
                req.fine = (int(weeks_late) + 1) * 500
            else:
                req.fine = 0
        else:
            req.fine = 0

    return render(request, 'library/pending_requests.html', {
        'requests': pending,
        'approved_requests': approved,
    })



@login_required
def return_book_view(request, request_id):
    if not hasattr(request.user, 'teacherprofile'):
        return HttpResponseForbidden("Only teachers can mark returns.")

    issue = BookIssueRequest.objects.get(id=request_id)
    issue.status = 'Returned'
    issue.returned_date = timezone.now().date()
    issue.save()
    messages.success(request, f"{issue.book.title} marked as returned.")
    return redirect('pending-requests')


@login_required
def approve_issue_view(request, request_id):
    if not hasattr(request.user, 'teacherprofile'):
        return HttpResponseForbidden("Only teachers can approve books.")

    issue = BookIssueRequest.objects.get(id=request_id)
    issue.status = 'Approved'
    issue.issued_date = timezone.now().date()
    issue.due_date = issue.issued_date + timedelta(days=7)
    issue.save()
    messages.success(request, f"{issue.book.title} issued to {issue.student.username}.")
    return redirect('pending-requests')  # We'll create this view/page next


@login_required
def request_issue_view(request, book_id):
    if not hasattr(request.user, 'studentprofile'):
        return HttpResponseForbidden("Only students can request books.")

    book = get_object_or_404(Book, id=book_id)

    # ✅ Prevent duplicate requests or re-issuing
    existing = BookIssueRequest.objects.filter(
        student=request.user,
        book=book,
        status__in=['Pending', 'Approved']
    )

    if existing.exists():
        messages.warning(request, "You’ve already requested or been issued this book.")
    else:
        BookIssueRequest.objects.create(
            student=request.user,
            book=book,
            status='Pending',
            requested_date=timezone.now()
        )
        messages.success(request, "Book request submitted successfully.")

    return redirect('view-books')

class RoleBasedLoginView(LoginView):
    template_name = 'login.html'

    def get_success_url(self):
        user = self.request.user
        if hasattr(user, 'studentprofile'):
            return '/students/dashboard/'  # ✅ Redirect to student dashboard
        elif hasattr(user, 'teacherprofile'):
            return '/teachers/dashboard/'  # ✅ Redirect to teacher dashboard
        else:
            return '/admin/'               # Optional fallback



@login_required
def view_books(request):
    if not (hasattr(request.user, 'studentprofile') or hasattr(request.user, 'teacherprofile') or request.user.is_superuser):
        return HttpResponseForbidden("Only students or teachers can view books.")


    books = Book.objects.all()

    # Search
    query = request.GET.get('q')
    if query:
        books = books.filter(
            Q(title__icontains=query) |
            Q(author__icontains=query) |
            Q(category__icontains=query)
        )

    # Sort
    sort_by = request.GET.get('sort')
    if sort_by in ['serial_number', 'title', 'author']:
        books = books.order_by(sort_by)

    return render(request, 'library/view_books.html', {
        'books': books,
        'query': query or '',
        'sort_by': sort_by or ''
    })


@login_required
def add_book(request):
    if not hasattr(request.user, 'teacherprofile'):
        return HttpResponseForbidden("Only teachers can add books.")

    if request.method == 'POST':
        serial = request.POST.get('serial_number')
        title = request.POST.get('title')
        author = request.POST.get('author')
        category = request.POST.get('category')
        description = request.POST.get('description')
        Book.objects.create(
            serial_number=serial,
            title=title,
            author=author,
            category=category,
            description=description
        )
        return redirect('view-books')

    return render(request, 'library/add_book.html')

@require_POST
@login_required
def cancel_request_view(request, request_id):
    try:
        req = BookIssueRequest.objects.get(id=request_id, student=request.user, status='Pending')
        req.delete()
        messages.success(request, "Book request cancelled.")
    except BookIssueRequest.DoesNotExist:
        messages.error(request, "Invalid request or already processed.")
    return redirect('student-dashboard')
