from django.contrib import admin
from .models import Book, BookIssueRequest
from django.utils import timezone
from datetime import timedelta

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'category', 'serial_number')
    search_fields = ('title', 'author', 'serial_number')
    list_filter = ('category',)

@admin.register(BookIssueRequest)
class BookIssueRequestAdmin(admin.ModelAdmin):
    list_display = ("book", "student", "status", "requested_date", "issued_date", "due_date")
    list_filter = ("status",)
    readonly_fields = ("book", "student", "status", "requested_date", "issued_date", "due_date")


@admin.action(description='Approve selected requests')
def approve_requests(modeladmin, request, queryset):
    for req in queryset.filter(status='Pending'):
        req.status = 'Approved'
        req.issued_date = timezone.now()
        req.due_date = timezone.now() + timedelta(days=7)
        req.save()

@admin.action(description='Mark as Returned')
def mark_as_returned(modeladmin, request, queryset):
    for req in queryset.filter(returned=False):
        req.returned = True
        req.save()




