from django.urls import path
from . import views

urlpatterns = [
    path('', views.view_books, name='view-books'),
    path('books/add/', views.add_book, name='add-book'),
    path('books/request/<int:book_id>/', views.request_issue_view, name='request-issue'),
    path('requests/', views.pending_requests_view, name='pending-requests'),
    path('requests/approve/<int:request_id>/', views.approve_issue_view, name='approve-issue'),
    path('requests/return/<int:request_id>/', views.return_book_view, name='return-book'),
    path('teachers/dashboard/', views.teacher_dashboard, name='teacher-dashboard'),
]
