from django.urls import path
from .views import teacher_register

urlpatterns = [
    path('register/', teacher_register, name='teacher-register'),
]
