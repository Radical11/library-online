from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login
from .forms import TeacherRegisterForm
from .models import TeacherProfile
from django.contrib.auth.decorators import login_required


def teacher_register(request):
    if request.method == 'POST':
        form = TeacherRegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            TeacherProfile.objects.create(user=user)
            return redirect('login')
    else:
        form = TeacherRegisterForm()
    return render(request, 'teachers/register.html', {'form': form})

@login_required
def add_books(request):
    if not hasattr(request.user, 'studentprofile'):
        return HttpResponseForbidden("Only teachers can add books.")

    books = Book.objects.all()
    return render(request, 'library/add_books.html', {'books': books})
